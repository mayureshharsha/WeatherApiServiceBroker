package com.mayuresh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.Cloud;
import org.springframework.cloud.CloudFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class WeatherApiServiceBrokerApplication {

	@Bean
	public Cloud cloud() {
		return new CloudFactory().getCloud();
	}

	public static void main(String[] args) {
		SpringApplication.run(WeatherApiServiceBrokerApplication.class, args);
	}

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
}
