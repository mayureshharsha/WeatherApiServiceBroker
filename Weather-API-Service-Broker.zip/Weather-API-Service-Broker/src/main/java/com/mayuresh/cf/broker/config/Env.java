package com.mayuresh.cf.broker.config;

// TODO: assignment: replace with a 'user defined service'
public class Env {

    public static String serviceHost;

    static {
        serviceHost = System.getenv("T_SERVICE_HOST");
    }
}
