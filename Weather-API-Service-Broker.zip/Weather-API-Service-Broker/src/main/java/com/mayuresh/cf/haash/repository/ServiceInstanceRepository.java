package com.mayuresh.cf.haash.repository;

import com.mayuresh.sb.model.ServiceInstance;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by pivotal on 6/26/14.
 */
@Repository
public interface ServiceInstanceRepository extends CrudRepository<ServiceInstance, String> {
}
