insert into services (id, name, description, bindable) values ('5', 'WeatherApi', 'WeatherApi - WeatherApi as a Service', true)
insert into plans (id, name, description, service_id) values ('10', 'basic', 'Basic Plan','5');
